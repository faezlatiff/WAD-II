/*
    
Name:   KIM Jong Un
Email:  kim.jongun.2020

*/


function get_max(url1, url2, ele_id) {
    /*
    Assume list1 and list2 are the lists obtained from url1 and url2
    the output to be displayed in HTML element with id ele_id
        url1 + " : " + JSON.stringify(list1) + "<br>" +
        url2 + " : " + JSON.stringify(list2) + "<br>" +
        "max : " + max
    
    For failed AJAX calls, assuming url1 fails
        url1 + "<br>" + error;
    */

    // YOUR CODE GOES HERE: START

    

    // YOUR CODE GOES HERE: END
}
